# Baker's Dozen
Baker’s Dozen is a recipe management application designed for people who enjoy cooking and baking, and like to create, edit, and share recipes that they’ve made.

Jüri Kiin

Features:
- Switch between views
- Structure in place for adding/viewing recipes

##Checkpoint 1:

##Checkpoint 2:


##Checkpoint Final:




