//
//  ImageCell.swift
//  BakersDozen
//
//  Created by Juri Kiin on 4/11/18.
//  Copyright © 2018 Juri Kiin. All rights reserved.
//

import UIKit

class ImageCell: UITableViewCell, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet var photoImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
