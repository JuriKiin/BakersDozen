//
//  RecipeCell.swift
//  BakersDozen
//
//  Created by Juri Kiin on 4/12/18.
//  Copyright © 2018 Juri Kiin. All rights reserved.
//

import UIKit

class RecipeCell: UITableViewCell {

    var recipe = Recipe()
}
