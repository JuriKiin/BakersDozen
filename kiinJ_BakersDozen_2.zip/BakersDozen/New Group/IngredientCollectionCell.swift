//
//  IngredientCell.swift
//  BakersDozen
//
//  Created by Juri Kiin on 4/10/18.
//  Copyright © 2018 Juri Kiin. All rights reserved.
//

import UIKit

class IngredientCollectionCell: UICollectionViewCell {
    @IBOutlet var name: UILabel!
}
